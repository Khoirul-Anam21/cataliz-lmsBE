import { config } from "dotenv";

config();

export const appName = "workshop-api";
