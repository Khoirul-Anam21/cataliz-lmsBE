# Commands Directory

This directory is for your custom commands

```
commands
├── command-1
│   └── index.command.ts
│   └── index.spec.ts
└── command-2
    └── index.command.ts
    └── index.spec.ts
```

## Make Command

```bash
node cli make:command <command>
```