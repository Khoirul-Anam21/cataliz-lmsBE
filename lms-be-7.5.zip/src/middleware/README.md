# Middleware Directory

This directory is for your custom middleware

```
middleware
├── middleware-1
│   └── index.middleware.ts
│   └── index.spec.ts
└── middleware-2
    └── index.middleware.ts
    └── index.spec.ts
```

## Make Command

```bash
node cli make:middleware <middleware>
```