import { ApiError } from "@point-hub/express-error-handler";
import Validatorjs from "validatorjs";

export const validateReadManyComments = (body: any) => {
  const validation = new Validatorjs(body, {
    id: "required|size:24",
  });

  if (validation.fails()) {
    throw new ApiError(422, validation.errors.errors);
  }
};
