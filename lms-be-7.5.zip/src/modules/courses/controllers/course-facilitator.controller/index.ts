
export { readMany } from "./read-many.controller.js";