export { create } from "./create.controller.js";
export { readMany } from "./read-many.controller.js";
export { completeCourseContent } from "./complete-content.controller.js";