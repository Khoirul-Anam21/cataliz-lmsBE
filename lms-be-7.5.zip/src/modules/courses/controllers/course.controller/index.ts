export { read } from "./read.controller.js";
export { create } from "./create.controller.js";
export { readMany } from "./read-many.controller.js";
export { readManyCourseParticipant } from "./read-many-participant.controller.js";
export { publishCourse } from "./publish-course.controller.js"
export { update } from "./update.controller.js";
export { destroy } from "./destroy.controller.js";
