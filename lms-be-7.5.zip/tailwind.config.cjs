module.exports = {
  content: ["./src/**/*.{hbs,handlebars}"],
  darkMode: "media",
  theme: {},
  plugins: [],
};
